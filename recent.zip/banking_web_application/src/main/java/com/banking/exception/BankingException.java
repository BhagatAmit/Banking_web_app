package com.banking.exception;

public class BankingException extends Exception {

	public BankingException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public BankingException(final String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}


}
